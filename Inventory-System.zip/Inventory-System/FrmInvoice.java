/*
       WALA NA ADD AnG CONTols SA  JPANEL , KINI JDIALOG , pag himp ug inv form
*/

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;

public class FrmInvoice extends JInternalFrame
{
	
	public FrmInvoice()
	{
		
	}

	// private methods

	/////////////////////////////// end of methods ///////////////////////////////
}